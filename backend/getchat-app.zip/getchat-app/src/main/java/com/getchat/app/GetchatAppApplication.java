package com.getchat.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GetchatAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(GetchatAppApplication.class, args);
	}

}
